import { BrowserModule } from '@angular/platform-browser';
import { NgModule, Component } from '@angular/core';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { RouterModule,Route } from '@angular/router';
import { AdminLoginComponent } from './Admin/login/login.component';
import { HttpClientModule } from '@angular/common/http';
import { ClientService }  from './Client/Client.service';
import { FormsModule } from '@angular/forms'
import { ClientRegisterComponent } from './Client/register/Client.register.component';
import { ClientLoginComponent } from './Client/login/login.component';
import { ClientAddComponent} from './Client/add/client.add.component';
import { ClientListComponent} from './Client/List/client.list.component';
import { HomeComponent } from './Admin/Home/home.component';
import { from } from 'rxjs';

const routes : Route[]=[

  {path :'Admin-login', component:AdminLoginComponent },



  {path :'Client-login', component:ClientLoginComponent },
  {path :'Client-register', component:ClientRegisterComponent},

  {path :'Client-add',component:ClientAddComponent},
  {path :'Client-List',component:ClientListComponent},

  {path :'adminHome',component:HomeComponent}

  

]

@NgModule({
  declarations: [
    AppComponent,
    AdminLoginComponent,
    ClientRegisterComponent,
    ClientLoginComponent,
    ClientAddComponent,
    ClientListComponent,
    HomeComponent
    
   
  ],
  imports: [

  BrowserModule,
  HttpClientModule,
  FormsModule,
    RouterModule.forRoot(routes),
    AppRoutingModule

  ],
  providers: [
    
    ClientService
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
